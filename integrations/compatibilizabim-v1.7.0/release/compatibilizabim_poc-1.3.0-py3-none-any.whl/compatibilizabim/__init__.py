"""CompatibilizaBIM engine."""

__version__ = "1.3.0"
